<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>search invalid keyword test suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>a2eee26c-b1f0-464b-9221-f71485ee4194</testSuiteGuid>
   <testCaseLink>
      <guid>38b0ffe5-ecab-4c74-ad75-22967c0e46e6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <iterationNameVariable>
         <defaultValue>''</defaultValue>
         <description></description>
         <id>650401c1-d2f8-48de-9d2f-972d34379218</id>
         <masked>false</masked>
         <name>keyword</name>
      </iterationNameVariable>
      <testCaseId>Test Cases/search book invalid keyword</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>144731c9-39e6-4a40-a8d6-fa78db349860</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/search invalid keyword</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>144731c9-39e6-4a40-a8d6-fa78db349860</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>keyword</value>
         <variableId>650401c1-d2f8-48de-9d2f-972d34379218</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
