<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>test suite (not filled enough info)</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>20a44ec7-6b15-46d1-9a79-46a72893d662</testSuiteGuid>
   <testCaseLink>
      <guid>0bc44122-43c8-49f3-a7a9-9717f54c6c88</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/share-book not filled enough info</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>4127dc42-6e81-4593-926a-617375423a12</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/share-book not filled enough info</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>4127dc42-6e81-4593-926a-617375423a12</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Book Author</value>
         <variableId>4933f9c6-03a2-44bb-a116-43643cd7ad3b</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>4127dc42-6e81-4593-926a-617375423a12</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Address</value>
         <variableId>12848b37-eba8-4a5e-bed8-0c7e0a6d91a6</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
