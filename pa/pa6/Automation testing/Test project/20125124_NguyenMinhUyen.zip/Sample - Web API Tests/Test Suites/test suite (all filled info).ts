<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>test suite (all filled info)</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>22e14c8f-516c-47b2-8077-c75bcee0c6af</testSuiteGuid>
   <testCaseLink>
      <guid>f8b14b55-0dc7-4634-969b-9530a5600f6b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/share-book all filled info</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>a8953c40-bee1-4416-84c0-6e6f215206fb</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/share-book all filled data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>a8953c40-bee1-4416-84c0-6e6f215206fb</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Book Title</value>
         <variableId>6242e808-b471-4323-921b-2e53b9cbcbae</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>a8953c40-bee1-4416-84c0-6e6f215206fb</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Book Author</value>
         <variableId>e65b750c-3d29-4312-8b02-bc8250bb7976</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>a8953c40-bee1-4416-84c0-6e6f215206fb</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Address</value>
         <variableId>491b6116-e07b-4fa7-9841-6d4b4a4114f8</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
