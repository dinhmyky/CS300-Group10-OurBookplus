<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Last chapter (last page)</name>
   <tag></tag>
   <elementGuidId>755eefef-bbad-450e-8f37-63975155024b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Chapter 1 (first page) +'])[1]/following::label[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>47374816-9df8-4b6f-a192-494a86cb6b83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>btn-4</value>
      <webElementGuid>91c259bf-f1a4-4484-8a7a-0f0efc4a0394</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Last chapter (last page) +</value>
      <webElementGuid>bde35238-fbed-4392-b2f4-56d531b30f47</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;share-book&quot;]/div[@class=&quot;photo-button&quot;]/label[4]</value>
      <webElementGuid>d071518b-8dde-4bb4-8b73-3aeefd1119cd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chapter 1 (first page) +'])[1]/following::label[1]</value>
      <webElementGuid>bc48718f-6ae9-43d3-a73d-69377803df3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content photo +'])[1]/following::label[2]</value>
      <webElementGuid>4f800836-bba9-4a4a-bb4c-11c82d8fa94b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/preceding::label[1]</value>
      <webElementGuid>03421d3f-d338-449b-92de-f466a8bf81f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload'])[1]/preceding::label[2]</value>
      <webElementGuid>85f37fc3-6e09-437d-9b0f-d1e64dcdf5f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Last chapter (last page) +']/parent::*</value>
      <webElementGuid>0576cf07-1028-459a-a9ab-d22af1220881</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[4]</value>
      <webElementGuid>9c07b5bd-9f99-43cf-b240-0d4cfe6e7479</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Last chapter (last page) +' or . = 'Last chapter (last page) +')]</value>
      <webElementGuid>966fcef0-eb28-45b5-a28b-472db4e971a9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
