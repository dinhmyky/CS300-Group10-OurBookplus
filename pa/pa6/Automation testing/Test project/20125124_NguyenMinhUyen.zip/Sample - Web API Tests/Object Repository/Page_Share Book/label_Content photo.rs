<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Content photo</name>
   <tag></tag>
   <elementGuidId>6f0c4ddb-64d5-45dc-9838-3887e1b597d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Cover photo +'])[1]/following::label[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>0110240e-cb36-4bce-9506-f385c170f5d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>btn-2</value>
      <webElementGuid>10d6c857-86d5-4d40-96f5-e2f6ca948509</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Content photo +</value>
      <webElementGuid>70898806-e34e-4d64-848b-557c70b1f340</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;share-book&quot;]/div[@class=&quot;photo-button&quot;]/label[2]</value>
      <webElementGuid>cfc0becc-33ff-4e0b-bcdf-6a60476c65c3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cover photo +'])[1]/following::label[1]</value>
      <webElementGuid>ec02b712-426c-425e-9641-59c82794eae6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Author'])[1]/following::label[2]</value>
      <webElementGuid>6a0d7bf7-f59a-4b7c-9738-fc211ca63080</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chapter 1 (first page) +'])[1]/preceding::label[1]</value>
      <webElementGuid>f545c876-de8c-46f5-b9cd-63d2b2ce1f9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last chapter (last page) +'])[1]/preceding::label[2]</value>
      <webElementGuid>5d77b02e-6dbf-411f-b751-3555a4cd8e8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Content photo +']/parent::*</value>
      <webElementGuid>93008d0e-d06b-4bc4-9a11-6f0ac88ad4a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[2]</value>
      <webElementGuid>bac6d117-55d6-44ba-83ef-26652d644eec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Content photo +' or . = 'Content photo +')]</value>
      <webElementGuid>a7e209b7-2700-4df9-a6b6-a17fc05f2e83</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
