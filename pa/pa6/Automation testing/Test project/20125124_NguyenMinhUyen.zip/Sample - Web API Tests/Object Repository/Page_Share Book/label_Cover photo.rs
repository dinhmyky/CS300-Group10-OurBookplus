<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Cover photo</name>
   <tag></tag>
   <elementGuidId>951130a8-6de0-4b65-94b7-850ff9bb7942</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.photo-button > label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Author'])[1]/following::label[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>3140eec2-6ff8-4b33-ac2a-2861d36ab395</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>btn-1</value>
      <webElementGuid>1c1e0122-78c9-45f4-9312-6187b0d05249</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cover photo +</value>
      <webElementGuid>54e4bde9-d14f-4106-837f-e223ced77ab5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;share-book&quot;]/div[@class=&quot;photo-button&quot;]/label[1]</value>
      <webElementGuid>272aa94f-5f81-40fb-8f94-5d03d4e83222</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Author'])[1]/following::label[1]</value>
      <webElementGuid>b295f0ed-4af1-4e05-a338-befe6a19909e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Title'])[1]/following::label[2]</value>
      <webElementGuid>3b284f36-43de-47d5-a52e-8ad80600ebb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content photo +'])[1]/preceding::label[1]</value>
      <webElementGuid>ed2447ee-d869-4bae-a6e3-b9de13fbab61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chapter 1 (first page) +'])[1]/preceding::label[2]</value>
      <webElementGuid>10f369b3-a13f-4b84-a246-54a519794ec6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Cover photo +']/parent::*</value>
      <webElementGuid>29d988f0-3548-4fc0-911f-e80e3db7d8c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/label</value>
      <webElementGuid>43966386-1139-41e6-9b93-bcb25a64eeff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Cover photo +' or . = 'Cover photo +')]</value>
      <webElementGuid>f241b0ab-9242-42fc-b830-5e4c9aa81749</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
