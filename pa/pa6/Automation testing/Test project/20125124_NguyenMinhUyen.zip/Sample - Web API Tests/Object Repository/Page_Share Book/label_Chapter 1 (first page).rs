<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Chapter 1 (first page)</name>
   <tag></tag>
   <elementGuidId>849e5c93-aabf-4d17-a0f5-bb79ed6b49dd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Content photo +'])[1]/following::label[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>d1b0b6ab-1129-41bf-8fd7-68c70f406f71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>btn-3</value>
      <webElementGuid>7582c35e-871c-46ab-971f-a1c0631cdf95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chapter 1 (first page) +</value>
      <webElementGuid>20032b24-2701-4eb1-bcb8-b1d690861eb5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;share-book&quot;]/div[@class=&quot;photo-button&quot;]/label[3]</value>
      <webElementGuid>7556eac5-6d00-4c8e-bb74-8f7582e60763</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content photo +'])[1]/following::label[1]</value>
      <webElementGuid>17f27575-df4d-45bc-944d-0571516060a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cover photo +'])[1]/following::label[2]</value>
      <webElementGuid>ca586d21-e43b-4387-96e1-13d1c983a6bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last chapter (last page) +'])[1]/preceding::label[1]</value>
      <webElementGuid>07311c2b-673e-4fc9-8115-ebbfec20c7b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/preceding::label[2]</value>
      <webElementGuid>b8b747f9-db28-4d9e-882c-7c1aebb83c3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chapter 1 (first page) +']/parent::*</value>
      <webElementGuid>06457605-ff80-4323-b229-1503b0ffcd60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[3]</value>
      <webElementGuid>152689d4-b6ae-47a9-8884-e6f288c14909</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Chapter 1 (first page) +' or . = 'Chapter 1 (first page) +')]</value>
      <webElementGuid>e4118984-98a1-46e8-823d-dc99ec60370d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
