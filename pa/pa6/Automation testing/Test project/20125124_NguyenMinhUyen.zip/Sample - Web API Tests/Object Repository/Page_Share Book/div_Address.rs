<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Address</name>
   <tag></tag>
   <elementGuidId>8095afcf-1234-4523-8b90-17c812b1b251</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.address</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Last chapter (last page) +'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a8b80a7d-142a-4eef-a51f-f2124707b39a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>address</value>
      <webElementGuid>1575a6ab-c52a-437b-8b00-c9ad7d7f03b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    Address
    
      
    
  </value>
      <webElementGuid>a9bc9c1b-f0f9-4b98-925b-1584349c329f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;share-book&quot;]/div[@class=&quot;address&quot;]</value>
      <webElementGuid>90728fc0-a4d5-4bae-a754-555b57380e9b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last chapter (last page) +'])[1]/following::div[1]</value>
      <webElementGuid>39514001-8697-4812-a9cd-857d971620fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chapter 1 (first page) +'])[1]/following::div[1]</value>
      <webElementGuid>d323a8a4-28e6-42a4-8c82-ada9fe6dc8ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload'])[1]/preceding::div[2]</value>
      <webElementGuid>144b50da-2023-4c52-86b4-041cf07f0a0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]</value>
      <webElementGuid>c7befa72-3c10-4b64-bf50-e33c4cfc6c8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    Address
    
      
    
  ' or . = '
    Address
    
      
    
  ')]</value>
      <webElementGuid>ee0b14d7-2d60-4d81-8743-e5966cffe7ae</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
